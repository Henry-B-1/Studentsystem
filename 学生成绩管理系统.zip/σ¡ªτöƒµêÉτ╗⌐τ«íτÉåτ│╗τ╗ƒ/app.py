from flask import Flask, render_template, redirect, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

class Config:
    SQLALCHEMY_DATABASE_URI='mysql+pymysql://root:admin@localhost:3306/flaskdb'
    SQLALCHEMY_TRACK_MODIFICATIONS=True

app.config.from_object(Config)
db=SQLAlchemy(app)

app.secret_key='SOFTWARE'

class User(db.Model):
    __tablename__='user_info'
    id=db.Column(db.Integer,primary_key=True,
                autoincrement=True,nullable=True)
    user_name=db.Column(db.String(100),nullable=True)
    user_email=db.Column(db.String(100),nullable=True)
    user_password=db.Column(db.String(100),nullable=True)

class Score(db.Model):
    __tablename__='score_info'
    id=db.Column(db.Integer,primary_key=True,
                autoincrement=True,nullable=True)
    stu_name=db.Column(db.String(100),nullable=True)
    stu_chinese=db.Column(db.String(100),nullable=True)
    stu_math=db.Column(db.String(100),nullable=True)
    stu_english=db.Column(db.String(100),nullable=True)

@app.route('/',methods=['POST','GET'])
def func_login():
    db.create_all()
    error=None
    if request.method =='POST':
        but1 = request.values.get('btn1')
        but2 = request.values.get('btn2')

        log_name = request.form.get('l_name')
        log_pwd = request.form.get('l_pwd')

        reg_name = request.form.get('r_name')
        reg_email = request.form.get('r_email')
        reg_pwd = request.form.get('r_pwd')

        if but2 == 'r_but':

            dbuser = User.query.filter_by(user_name=reg_name).first()
            if dbuser:
                error ='用户名已存在'
                return render_template('login.html',error=error)
            else:
                user =User(user_name=reg_name,
                           user_email=reg_email,
                           user_password=reg_pwd )    
                db.session.add(user)
                db.session.commit()
                return redirect('/admin')
        elif but1 == 'l_but':
            dbuser = User.query.filter_by(user_name=reg_name).first()
            if dbuser and log_pwd==dbuser.user_password:
                return redirect('/admin')
            else:
                error='用户名或密码错误！'
                return render_template('login.html',error=error)
    return render_template('login.html',error=error)

@app.route('/admin')
def fuin_admin():
    users=User.query.all()
    scores=Score.query.all()
    return render_template('admin.html',users=users,scores=scores)

@app.route('/add',methods=['GET','POST'])
def add():
    if request.method =='POST':
        username=request.form.get('username')
        chinese=request.form.get('chinese')
        math=request.form.get('math')
        english=request.form.get('english')

        stu=Score(stu_name=username,
                stu_chinese=chinese,
                stu_math=math,
                stu_english=english)
        db.session.add(stu)
        db.session.commit()
        return redirect('/admin')
    return render_template('add.html')

@app.route('/change',methods=['GET','POST'])
def change():
    change_id = request.args.get('id')
    student =Score.query.get(change_id)

    if request.method == 'POST':
        username=request.form.get('username')
        chinese=request.form.get('chinese')
        math=request.form.get('math')
        english=request.form.get('english')

        student.stu_name=username,
        student.stu_chinese=chinese,
        student.stu_math=math,
        student.stu_english=english
        db.session.commit()
        return redirect('/admin')
    return render_template('change.html',student=student)

@app.route('/delete')
def delete():
    del_id = request.args.get('id')
    stu =Score.query.get(del_id)
    db.session.delete(stu)
    db.session.commit()
    return redirect('/admin')






if __name__ == '__main__':
    app.run(debug=True, port=8000)
